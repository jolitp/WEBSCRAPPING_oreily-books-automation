/************************************************************************/
/*                                                                      */
/*      Save Page WE - Generic WebExtension - Options Page              */
/*                                                                      */
/*      Javascript for Options Page                                     */
/*                                                                      */
/*      Last Edit - 13 Mar 2021                                         */
/*                                                                      */
/*      Copyright (C) 2016-2021 DW-dev                                  */
/*                                                                      */
/*      Distributed under the GNU General Public License version 2      */
/*      See LICENCE.txt file and http://www.gnu.org/licenses/           */
/*                                                                      */
/************************************************************************/

/************************************************************************/
/*                                                                      */
/*  Refer to Google Chrome developer documentation:                     */
/*                                                                      */
/*  https://developer.chrome.com/extensions/optionsV2                   */
/*                                                                      */
/*  https://developer.chrome.com/extensions/storage                     */
/*                                                                      */
/************************************************************************/

"use strict";

/************************************************************************/

/* Global variables */

var isFirefox;
var ffVersion;

var platformOS;

/************************************************************************/

/* Listener for options page load */

document.addEventListener("DOMContentLoaded",onLoadPage,false);

/************************************************************************/

/* Initialize on page load */

function onLoadPage(event)
{
    /* Load options from local storage */
    
    chrome.storage.local.get(null,
    function(object)
    {
        /* Load environment */
        
        isFirefox = object["environment-isfirefox"];
        
        if (isFirefox) ffVersion = object["environment-ffversion"];
        
        platformOS = object["environment-platformos"];
        
        if (isFirefox) document.body.setAttribute("isfirefox","");
	    
        if (isFirefox && ffVersion >= 60) document.body.setAttribute("shortcuts","");
	    
        if (platformOS == "win") document.body.setAttribute("windows","");
        
        /* General options */
        
        document.getElementById("options-newbuttonaction").elements["type"].value = object["options-buttonactiontype"];
        document.getElementById("options-newbuttonaction").elements["items"].value = object["options-buttonactionitems"];
        
        document.getElementById("options-showsubmenu").checked = object["options-showsubmenu"];
        document.getElementById("options-showwarning").checked = object["options-showwarning"];
        document.getElementById("options-showresources").checked = object["options-showresources"];
        document.getElementById("options-promptcomments").checked = object["options-promptcomments"];
        document.getElementById("options-skipwarningscomments").checked = object["options-skipwarningscomments"];
        document.getElementById("options-usenewsavemethod").checked = object["options-usenewsavemethod"];
        document.getElementById("options-showsaveasdialog").checked = object["options-showsaveasdialog"];
        document.getElementById("options-closetabafter").checked = object["options-closetabafter"];
        
        document.getElementById("options-loadlazycontent").checked = object["options-loadlazycontent"];
        document.getElementById("options-lazyloadtype").value = object["options-lazyloadtype"];
        document.getElementById("options-loadlazyimages").checked = object["options-loadlazyimages"];
        document.getElementById("options-retaincrossframes").checked = object["options-retaincrossframes"];
        document.getElementById("options-mergecssimages").checked = object["options-mergecssimages"];
        document.getElementById("options-executescripts").checked = object["options-executescripts"];
        document.getElementById("options-removeunsavedurls").checked = object["options-removeunsavedurls"];
        document.getElementById("options-removeelements").checked = object["options-removeelements"];
        document.getElementById("options-rehideelements").checked = object["options-rehideelements"];
        document.getElementById("options-includeinfobar").checked = object["options-includeinfobar"];
        document.getElementById("options-includesummary").checked = object["options-includesummary"];
        document.getElementById("options-formathtml").checked = object["options-formathtml"];
        
        document.getElementById("options-skipwarningscomments").disabled = !(document.getElementById("options-showwarning").checked ||
                                                                             document.getElementById("options-showresources").checked ||
                                                                             document.getElementById("options-promptcomments").checked);
        
        document.getElementById("options-showsaveasdialog").disabled = !document.getElementById("options-usenewsavemethod").checked;
        
        document.getElementById("options-rehideelements").disabled = document.getElementById("options-removeelements").checked;
        
        /* Saved Items options */
        
        document.getElementById("options-savehtmlaudiovideo").checked = object["options-savehtmlaudiovideo"];
        document.getElementById("options-savehtmlobjectembed").checked = object["options-savehtmlobjectembed"];
        document.getElementById("options-savehtmlimagesall").checked = object["options-savehtmlimagesall"];
        document.getElementById("options-savecssimagesall").checked = object["options-savecssimagesall"];
        document.getElementById("options-savecssfontswoff").checked = object["options-savecssfontswoff"];
        document.getElementById("options-savecssfontsall").checked = object["options-savecssfontsall"];
        document.getElementById("options-savescripts").checked = object["options-savescripts"];
        
        document.getElementById("options-savecssfontswoff").disabled = document.getElementById("options-savecssfontsall").checked;
        
        /* File Info options */
        
        document.getElementById("options-urllistname").textContent = object["options-urllistname"];
        document.getElementById("options-urllistsize").textContent = object["options-urllisturls"].length + " URLs Listed";
        
        document.getElementById("options-savedfilename").value = object["options-savedfilename"];
        document.getElementById("options-replacespaces").checked = object["options-replacespaces"];
        document.getElementById("options-replacechar").value = object["options-replacechar"];
        document.getElementById("options-maxfilenamelength").value = object["options-maxfilenamelength"];
        
        document.getElementById("options-replacechar").disabled = !document.getElementById("options-replacespaces").checked;
        
        /* Advanced options */
        
        document.getElementById("options-urllisttime").value = object["options-urllisttime"];
        document.getElementById("options-lazyloadscrolltime").value = object["options-lazyloadscrolltime"];
        document.getElementById("options-lazyloadshrinktime").value = object["options-lazyloadshrinktime"];
        document.getElementById("options-maxframedepth").value = object["options-maxframedepth"];
        document.getElementById("options-maxresourcesize").value = object["options-maxresourcesize"];
        document.getElementById("options-maxresourcetime").value = object["options-maxresourcetime"];
        document.getElementById("options-allowpassive").checked = object["options-allowpassive"];
        document.getElementById("options-refererheader").elements["header"].value = object["options-refererheader"];
        document.getElementById("options-useautomation").checked = object["options-useautomation"];
        
        /* Keyboard shortcuts */
        
        if (isFirefox && ffVersion >= 60)
        {
            chrome.commands.getAll(
            function(commands)
            {
                var i;
                
                for (i = 0; i < commands.length; i++)
                {
                    if (commands[i].name == "_execute_browser_action") document.getElementById("options-shortcuts-browseraction").value = commands[i].shortcut;
                    else if (commands[i].name == "cancelsave") document.getElementById("options-shortcuts-cancelsave").value = commands[i].shortcut;
                }
            });
        }
        
        /* Add listeners for click on tab buttons */
        
        document.getElementById("options-tabbar-general").addEventListener("click",showGeneralTab,false);
        document.getElementById("options-tabbar-saveditems").addEventListener("click",showSavedItemsTab,false);
        document.getElementById("options-tabbar-fileinfo").addEventListener("click",showFileInfoTab,false);
        document.getElementById("options-tabbar-advanced").addEventListener("click",showAdvancedTab,false);
        document.getElementById("options-tabbar-shortcuts").addEventListener("click",showShortcutsTab,false);
        
        /* Add listener for click on show warning checkbox */
        
        document.getElementById("options-showwarning").addEventListener("click",onClickShowWarning,false);
        
        /* Add listener for click on show resources checkbox */
        
        document.getElementById("options-showresources").addEventListener("click",onClickShowResources,false);
        
        /* Add listener for click on prompt comments checkbox */
        
        document.getElementById("options-promptcomments").addEventListener("click",onClickPromptComments,false);
        
        /* Add listener for click on use new save method checkbox */
        
        document.getElementById("options-usenewsavemethod").addEventListener("click",onClickUseNewSaveMethod,false);
        
        /* Add listener for click on remove elements checkbox */
        
        document.getElementById("options-removeelements").addEventListener("click",onClickRemoveElements,false);
        
        /* Add listener for click on save CSS fonts all checkbox */
        
        document.getElementById("options-savecssfontsall").addEventListener("click",onClickSaveCSSFontsAll,false);
        
        /* Add listener for change to URL list file input */
        
        document.getElementById("options-urllistfile").addEventListener("change",onChangeURLListFile,false);
        
        /* Add listener for click on URL list clear button */
        
        document.getElementById("options-urllistclear").addEventListener("click",onClickURLListClear,false);
        
        /* Add listener for click on predefined fields */
        
        document.getElementById("options-predefinedfields").addEventListener("click",onClickPredefinedFields,false);
        
        /* Add listener for click on replace spaces checkbox */
        
        document.getElementById("options-replacespaces").addEventListener("click",onClickReplaceSpaces,false);
        
        /* Add listener for click on save button */
        
        document.getElementById("options-save-button").addEventListener("click",onClickSave,false);
        
        /* Add listener for click on reset all button */
        
        document.getElementById("options-resetall-button").addEventListener("click",onClickResetAll,false);
        
        /* Wait for page layout to complete */
        
        window.setTimeout(
        function()
        {
            var width1,width2,width3,width4,width5,height1,height2,height3,height4,height5;
            
            /* Equalize widths of tabs */
            
            width1 = window.getComputedStyle(document.getElementById("options-tab-general"),null).getPropertyValue("width");
            width2 = window.getComputedStyle(document.getElementById("options-tab-saveditems"),null).getPropertyValue("width");
            width3 = window.getComputedStyle(document.getElementById("options-tab-fileinfo"),null).getPropertyValue("width");
            width4 = window.getComputedStyle(document.getElementById("options-tab-advanced"),null).getPropertyValue("width");
            width5 = window.getComputedStyle(document.getElementById("options-tab-shortcuts"),null).getPropertyValue("width");
            
            width1 = width1.substr(0,width1.length-2);
            width2 = width2.substr(0,width2.length-2);
            width3 = width3.substr(0,width3.length-2);
            width4 = width4.substr(0,width4.length-2);
            width5 = width5.substr(0,width5.length-2);
            
            width1 = Math.max(width1,width2,width3,width4,width5);
            
            document.getElementById("options-tab-general").style.setProperty("width",width1 + "px","");
            document.getElementById("options-tab-saveditems").style.setProperty("width",width1 + "px","");
            document.getElementById("options-tab-fileinfo").style.setProperty("width",width1 + "px","");
            document.getElementById("options-tab-advanced").style.setProperty("width",width1 + "px","");
            document.getElementById("options-tab-shortcuts").style.setProperty("width",width1 + "px","");
            
            /* Equalize heights of tabs */
            
            height1 = window.getComputedStyle(document.getElementById("options-tab-general"),null).getPropertyValue("height");
            height2 = window.getComputedStyle(document.getElementById("options-tab-saveditems"),null).getPropertyValue("height");
            height3 = window.getComputedStyle(document.getElementById("options-tab-fileinfo"),null).getPropertyValue("height");
            height4 = window.getComputedStyle(document.getElementById("options-tab-advanced"),null).getPropertyValue("height");
            height5 = window.getComputedStyle(document.getElementById("options-tab-shortcuts"),null).getPropertyValue("height");
            
            height1 = height1.substr(0,height1.length-2);
            height2 = height2.substr(0,height2.length-2);
            height3 = height3.substr(0,height3.length-2);
            height4 = height4.substr(0,height4.length-2);
            height5 = height5.substr(0,height5.length-2);
            
            height1 = Math.max(height1,height2,height3,height4,height5);
            
            document.getElementById("options-tab-general").style.setProperty("height",height1 + "px","");
            document.getElementById("options-tab-saveditems").style.setProperty("height",height1 + "px","");
            document.getElementById("options-tab-fileinfo").style.setProperty("height",height1 + "px","");
            document.getElementById("options-tab-advanced").style.setProperty("height",height1 + "px","");
            document.getElementById("options-tab-shortcuts").style.setProperty("height",height1 + "px","");
            
            /* Show general tab */
            
            showGeneralTab();
            
            document.getElementById("options").style.setProperty("opacity","1","");
        },50);
    });
}

/************************************************************************/

/* Select tab */

function showGeneralTab(event)
{
    document.getElementById("options-tabbar-general").setAttribute("selected","");
    document.getElementById("options-tabbar-saveditems").removeAttribute("selected");
    document.getElementById("options-tabbar-fileinfo").removeAttribute("selected");
    document.getElementById("options-tabbar-advanced").removeAttribute("selected");
    document.getElementById("options-tabbar-shortcuts").removeAttribute("selected");
    
    document.getElementById("options-tab-general").style.setProperty("display","block","");
    document.getElementById("options-tab-saveditems").style.setProperty("display","none","");
    document.getElementById("options-tab-fileinfo").style.setProperty("display","none","");
    document.getElementById("options-tab-advanced").style.setProperty("display","none","");
    document.getElementById("options-tab-shortcuts").style.setProperty("display","none","");
}

function showSavedItemsTab(event)
{
    document.getElementById("options-tabbar-general").removeAttribute("selected");
    document.getElementById("options-tabbar-saveditems").setAttribute("selected","");
    document.getElementById("options-tabbar-fileinfo").removeAttribute("selected");
    document.getElementById("options-tabbar-advanced").removeAttribute("selected");
    document.getElementById("options-tabbar-shortcuts").removeAttribute("selected");
    
    document.getElementById("options-tab-general").style.setProperty("display","none","");
    document.getElementById("options-tab-saveditems").style.setProperty("display","block","");
    document.getElementById("options-tab-fileinfo").style.setProperty("display","none","");
    document.getElementById("options-tab-advanced").style.setProperty("display","none","");
    document.getElementById("options-tab-shortcuts").style.setProperty("display","none","");
}

function showFileInfoTab(event)
{
    document.getElementById("options-tabbar-general").removeAttribute("selected");
    document.getElementById("options-tabbar-saveditems").removeAttribute("selected");
    document.getElementById("options-tabbar-fileinfo").setAttribute("selected","");
    document.getElementById("options-tabbar-advanced").removeAttribute("selected");
    document.getElementById("options-tabbar-shortcuts").removeAttribute("selected");
    
    document.getElementById("options-tab-general").style.setProperty("display","none","");
    document.getElementById("options-tab-saveditems").style.setProperty("display","none","");
    document.getElementById("options-tab-fileinfo").style.setProperty("display","block","");
    document.getElementById("options-tab-advanced").style.setProperty("display","none","");
    document.getElementById("options-tab-shortcuts").style.setProperty("display","none","");
}

function showAdvancedTab(event)
{
    document.getElementById("options-tabbar-general").removeAttribute("selected");
    document.getElementById("options-tabbar-saveditems").removeAttribute("selected");
    document.getElementById("options-tabbar-fileinfo").removeAttribute("selected");
    document.getElementById("options-tabbar-advanced").setAttribute("selected","");
    document.getElementById("options-tabbar-shortcuts").removeAttribute("selected");
    
    document.getElementById("options-tab-general").style.setProperty("display","none","");
    document.getElementById("options-tab-saveditems").style.setProperty("display","none","");
    document.getElementById("options-tab-fileinfo").style.setProperty("display","none","");
    document.getElementById("options-tab-advanced").style.setProperty("display","block","");
    document.getElementById("options-tab-shortcuts").style.setProperty("display","none","");
}

function showShortcutsTab(event)
{
    document.getElementById("options-tabbar-general").removeAttribute("selected");
    document.getElementById("options-tabbar-saveditems").removeAttribute("selected");
    document.getElementById("options-tabbar-fileinfo").removeAttribute("selected");
    document.getElementById("options-tabbar-advanced").removeAttribute("selected");
    document.getElementById("options-tabbar-shortcuts").setAttribute("selected","");
    
    document.getElementById("options-tab-general").style.setProperty("display","none","");
    document.getElementById("options-tab-saveditems").style.setProperty("display","none","");
    document.getElementById("options-tab-fileinfo").style.setProperty("display","none","");
    document.getElementById("options-tab-advanced").style.setProperty("display","none","");
    document.getElementById("options-tab-shortcuts").style.setProperty("display","block","");
}

/************************************************************************/

/* Enable or Disable options */

function onClickShowWarning(event)
{
    document.getElementById("options-skipwarningscomments").disabled = !(document.getElementById("options-showwarning").checked ||
                                                                         document.getElementById("options-showresources").checked ||
                                                                         document.getElementById("options-promptcomments").checked);
}

function onClickShowResources(event)
{
    document.getElementById("options-skipwarningscomments").disabled = !(document.getElementById("options-showwarning").checked ||
                                                                         document.getElementById("options-showresources").checked ||
                                                                         document.getElementById("options-promptcomments").checked);
}

function onClickPromptComments(event)
{
    document.getElementById("options-skipwarningscomments").disabled = !(document.getElementById("options-showwarning").checked ||
                                                                         document.getElementById("options-showresources").checked ||
                                                                         document.getElementById("options-promptcomments").checked);
}

function onClickUseNewSaveMethod(event)
{
    document.getElementById("options-showsaveasdialog").disabled = !document.getElementById("options-usenewsavemethod").checked;
}

function onClickRemoveElements(event)
{
    document.getElementById("options-rehideelements").disabled = document.getElementById("options-removeelements").checked;
}

function onClickSaveCSSFontsAll(event)
{
    document.getElementById("options-savecssfontswoff").disabled = document.getElementById("options-savecssfontsall").checked;
}

function onClickPredefinedFields(event)
{
    var element,value,start,end;
    
    if (event.target.localName == "label")
    {
        element = document.getElementById("options-savedfilename");
        
        if (event.target.textContent == "Clear Text") element.value = "";
        else
        {
            start = element.selectionStart;
            end = element.selectionEnd;
            
            element.value = element.value.slice(0,start) + event.target.textContent + element.value.slice(end);
            
            element.selectionStart = element.selectionEnd = start + event.target.textContent.length;
        }
        
        element.focus();
    }
}

function onClickReplaceSpaces(event)
{
    document.getElementById("options-replacechar").disabled = !document.getElementById("options-replacespaces").checked;
}

/************************************************************************/

/* Load URL list */

function onChangeURLListFile(event)
{
    var reader;
    
    reader = new FileReader();
    reader.onload = onload;
    reader.readAsText(event.target.files[0]);
    
    function onload()
    {
        var i,text,element,name;
        var urls = new Array();
        
        text = reader.result;
        
        urls = text.split("\n");
        
        for (i = urls.length-1; i >= 0; i--)
        {
            urls[i] = urls[i].trim();
            
            try { urls[i] = new URL(urls[i]).href; } catch (e) { urls.splice(i,1); continue; }
            
            if (specialPage(urls[i])) urls.splice(i,1);
        }
        
        element = document.getElementById("options-urllistname");
        
        element.textContent = name = event.target.value.substr(12);
        
        element.style.width = "auto";
        
        for (i = Math.trunc(name.length/2); element.offsetWidth > 292+6; i--)
        {
            element.textContent = name.substr(0,i) + "..." + name.substr(-i);
        }
        
        element.style.width = "";
        
        document.getElementById("options-urllistsize").textContent = urls.length + " URLs Listed";
        
        chrome.storage.local.set({ "options-urllisturls": urls, "options-urllistname": element.textContent });
    }
}

/************************************************************************/

/* Clear URL list */

function onClickURLListClear(event)
{
    var urls = new Array();
    
    document.getElementById("options-urllistname").textContent = "";
    
    document.getElementById("options-urllistsize").textContent = "0 URLs Listed";
    
    chrome.storage.local.set({ "options-urllisturls": urls, "options-urllistname": "" });
    
    event.preventDefault();
}

/************************************************************************/

/* Save options */

function onClickSave(event)
{
    /* Validate saved file name and replacement character */
    
    document.getElementById("options-savedfilename").value = document.getElementById("options-savedfilename").value.trim();
    
    if (document.getElementById("options-savedfilename").value == "")
        document.getElementById("options-savedfilename").value = "%TITLE%";
    
    if (document.getElementById("options-replacechar").value == "")
        document.getElementById("options-replacechar").value = "-";
    
    /* Save options to local storage */
    
    chrome.storage.local.set(
    {
        /* General options */
        
        "options-buttonactiontype": +document.getElementById("options-newbuttonaction").elements["type"].value,
        "options-buttonactionitems": +document.getElementById("options-newbuttonaction").elements["items"].value,
        
        "options-showsubmenu": document.getElementById("options-showsubmenu").checked,
        "options-showwarning": document.getElementById("options-showwarning").checked,
        "options-showresources": document.getElementById("options-showresources").checked,
        "options-promptcomments": document.getElementById("options-promptcomments").checked,
        "options-skipwarningscomments": document.getElementById("options-skipwarningscomments").checked,
        "options-usenewsavemethod": document.getElementById("options-usenewsavemethod").checked,
        "options-showsaveasdialog": document.getElementById("options-showsaveasdialog").checked,
        "options-closetabafter": document.getElementById("options-closetabafter").checked,
        
        "options-loadlazycontent": document.getElementById("options-loadlazycontent").checked,
        "options-lazyloadtype": document.getElementById("options-lazyloadtype").value,
        "options-loadlazyimages": document.getElementById("options-loadlazyimages").checked,
        "options-retaincrossframes": document.getElementById("options-retaincrossframes").checked,
        "options-mergecssimages": document.getElementById("options-mergecssimages").checked,
        "options-executescripts": document.getElementById("options-executescripts").checked,
        "options-removeunsavedurls": document.getElementById("options-removeunsavedurls").checked,
        "options-removeelements": document.getElementById("options-removeelements").checked,
        "options-rehideelements": document.getElementById("options-rehideelements").checked,
        "options-includeinfobar": document.getElementById("options-includeinfobar").checked,
        "options-includesummary": document.getElementById("options-includesummary").checked,
        "options-formathtml": document.getElementById("options-formathtml").checked,
        
        /* Saved Items options */
        
        "options-savehtmlaudiovideo": document.getElementById("options-savehtmlaudiovideo").checked,
        "options-savehtmlobjectembed": document.getElementById("options-savehtmlobjectembed").checked,
        "options-savehtmlimagesall": document.getElementById("options-savehtmlimagesall").checked,
        "options-savecssimagesall": document.getElementById("options-savecssimagesall").checked,
        "options-savecssfontswoff": document.getElementById("options-savecssfontswoff").checked,
        "options-savecssfontsall": document.getElementById("options-savecssfontsall").checked,
        "options-savescripts": document.getElementById("options-savescripts").checked,
        
        /* File Info options */
        
        "options-savedfilename": document.getElementById("options-savedfilename").value,
        "options-replacespaces": document.getElementById("options-replacespaces").checked,
        "options-replacechar": document.getElementById("options-replacechar").value,
        "options-maxfilenamelength": document.getElementById("options-maxfilenamelength").value,
        
        /* Advanced options */
        
        "options-urllisttime": +document.getElementById("options-urllisttime").value,
        "options-lazyloadscrolltime": +document.getElementById("options-lazyloadscrolltime").value,
        "options-lazyloadshrinktime": +document.getElementById("options-lazyloadshrinktime").value,
        "options-maxframedepth": +document.getElementById("options-maxframedepth").value,
        "options-maxresourcesize": +document.getElementById("options-maxresourcesize").value,
        "options-maxresourcetime": +document.getElementById("options-maxresourcetime").value,
        "options-allowpassive": document.getElementById("options-allowpassive").checked,
        "options-refererheader": +document.getElementById("options-refererheader").elements["header"].value,
        "options-useautomation": document.getElementById("options-useautomation").checked
    });
    
    /* Keyboard shortcuts */
    
    if (isFirefox && ffVersion >= 60)
    {
        try
        {
            chrome.commands.update({ name: "_execute_browser_action", shortcut: document.getElementById("options-shortcuts-browseraction").value });
        }
        catch (e)
        {
            chrome.commands.reset("_execute_browser_action");
            document.getElementById("options-shortcuts-browseraction").value = "Alt+A";
        }
        
        try
        {
            chrome.commands.update({ name: "cancelsave", shortcut: document.getElementById("options-shortcuts-cancelsave").value });
        }
        catch (e)
        {
            chrome.commands.reset("cancelsave");
            document.getElementById("options-shortcuts-cancelsave").value = "Alt+C";
        }
    }
    
    /* Display saved status for short period */
    
    document.getElementById("options-save-button").innerText = "Saved";
    document.getElementById("options-save-button").style.setProperty("font-weight","bold","");
    
    setTimeout(function()
    {
        document.getElementById("options-save-button").innerText = "Save";
        document.getElementById("options-save-button").style.setProperty("font-weight","normal","");
    }
    ,1000);
}

/************************************************************************/

/* Reset All options */

function onClickResetAll(event)
{
    /* General options */
    
    document.getElementById("options-newbuttonaction").elements["type"].value = 0;
    document.getElementById("options-newbuttonaction").elements["items"].value = 1;
    
    document.getElementById("options-showsubmenu").checked = true;
    document.getElementById("options-showwarning").checked = true;
    document.getElementById("options-showresources").checked = false;
    document.getElementById("options-promptcomments").checked = false;
    document.getElementById("options-skipwarningscomments").checked = true;
    document.getElementById("options-usenewsavemethod").checked = false;
    document.getElementById("options-showsaveasdialog").checked = false;
    document.getElementById("options-closetabafter").checked = false;
    
    document.getElementById("options-loadlazycontent").checked = false;
    document.getElementById("options-lazyloadtype").value = "1";
    document.getElementById("options-loadlazyimages").checked = true;
    document.getElementById("options-retaincrossframes").checked = true;
    document.getElementById("options-mergecssimages").checked = true;
    document.getElementById("options-executescripts").checked = false;
    document.getElementById("options-removeunsavedurls").checked = true;
    document.getElementById("options-removeelements").checked = false;
    document.getElementById("options-rehideelements").checked = false;
    document.getElementById("options-includeinfobar").checked = false;
    document.getElementById("options-includesummary").checked = false;
    document.getElementById("options-formathtml").checked = false;
    
    document.getElementById("options-skipwarningscomments").disabled = false;
    document.getElementById("options-showsaveasdialog").disabled = true;
    document.getElementById("options-rehideelements").disabled = false;
    
    /* Saved Items options */
    
    document.getElementById("options-savehtmlaudiovideo").checked = false;
    document.getElementById("options-savehtmlobjectembed").checked = false;
    document.getElementById("options-savehtmlimagesall").checked = false;
    document.getElementById("options-savecssimagesall").checked = false;
    document.getElementById("options-savecssfontswoff").checked = false;
    document.getElementById("options-savecssfontsall").checked = false;
    document.getElementById("options-savescripts").checked = false;
    
    document.getElementById("options-savecssfontswoff").disabled = false;
    
    /* File Info options */
    
    document.getElementById("options-savedfilename").value = "%TITLE%";
    document.getElementById("options-replacespaces").checked = false;
    document.getElementById("options-replacechar").value = "-";
    document.getElementById("options-maxfilenamelength").value = 150;
    
    document.getElementById("options-replacechar").disabled = true;
    
    /* Advanced options */
    
    document.getElementById("options-urllisttime").value = 10;
    document.getElementById("options-lazyloadscrolltime").value = 0.2;
    document.getElementById("options-lazyloadshrinktime").value = 0.5;
    document.getElementById("options-maxframedepth").value = 5;
    document.getElementById("options-maxresourcesize").value = 50;
    document.getElementById("options-maxresourcetime").value = 10;
    document.getElementById("options-allowpassive").checked = false;
    document.getElementById("options-refererheader").elements["header"].value = 0;
    document.getElementById("options-useautomation").checked = false;
    
    /* Keyboard shortcuts */
    
    if (isFirefox && ffVersion >= 60)
    {
        document.getElementById("options-shortcuts-browseraction").value = "Alt+A";
        document.getElementById("options-shortcuts-cancelsave").value = "Alt+C";
    }
    
    /* Display reset status for short period */
    
    document.getElementById("options-resetall-button").innerText = "Reset";
    document.getElementById("options-resetall-button").style.setProperty("font-weight","bold","");
    
    setTimeout(function()
    {
        document.getElementById("options-resetall-button").innerText = "Reset All";
        document.getElementById("options-resetall-button").style.setProperty("font-weight","normal","");
    }
    ,1000);
}

/************************************************************************/

/* Special page function */

function specialPage(url)
{
    return (url.substr(0,6) == "about:" || url.substr(0,7) == "chrome:" || url.substr(0,12) == "view-source:" ||
            url.substr(0,14) == "moz-extension:" || url.substr(0,26) == "https://addons.mozilla.org" || url.substr(0,27) == "https://support.mozilla.org" ||
            url.substr(0,17) == "chrome-extension:" || url.substr(0,34) == "https://chrome.google.com/webstore");
}

/************************************************************************/
